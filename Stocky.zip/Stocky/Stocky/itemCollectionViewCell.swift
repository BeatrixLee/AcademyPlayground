//
//  itemCollectionViewCell.swift
//  Stocky
//
//  Created by Beatrix Lee on 05/03/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import UIKit

class itemCollectionViewCell: UICollectionViewCell {
     
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var labelNome: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
